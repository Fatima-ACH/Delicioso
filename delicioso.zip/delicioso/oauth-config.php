<?php
// Google OAuth Configuration
define('GOOGLE_CLIENT_ID', '641786285968-dm43m3hof8kppsfhsuvcdaj58gbdsmbg.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', 'http://localhost/delicioso/google-callback.php');

// Facebook OAuth Configuration
define('FACEBOOK_APP_ID', '1158128539847719');
define('FACEBOOK_APP_SECRET', '422b1e13cfd54eeb4bc68420dd87d104');
define('FACEBOOK_REDIRECT_URI', 'http://localhost/delicioso/facebook-callback.php');

// For production - comment out the localhost lines above and uncomment these:
// define('GOOGLE_REDIRECT_URI', 'https://yourdomain.com/google-callback.php');
// define('FACEBOOK_REDIRECT_URI', 'https://yourdomain.com/facebook-callback.php');
?>