// Animated Logout Button Functionality
document.addEventListener('DOMContentLoaded', function() {
    // Simple function to check if user is logged in
    function isUserLoggedIn() {
        // Check the body data attribute first
        const bodyLoggedIn = document.body.getAttribute('data-logged-in');
        if (bodyLoggedIn === 'true') return true;
        if (bodyLoggedIn === 'false') return false;
        
        // Fallback: check for PHP session cookie
        return document.cookie.includes('PHPSESSID');
    }
    
    // Update button text based on login status
    function updateButtonText(button) {
        const isLoggedIn = isUserLoggedIn();
        const buttonText = button.querySelector('.button-text');
        
        if (buttonText) {
            buttonText.textContent = isLoggedIn ? 'Logout' : 'Login';
            console.log('Button updated:', buttonText.textContent, 'Logged in:', isLoggedIn);
        }
    }
    
    // Initialize all logout buttons
    document.querySelectorAll('.logoutButton').forEach(button => {
        console.log('Initializing button...');
        
        // Set initial state
        button.state = 'default';
        
        // Update button text immediately
        updateButtonText(button);
    
        // function to transition a button from one state to the next
        let updateButtonState = (button, state) => {
            if (logoutButtonStates[state]) {
                button.state = state;
                for (let key in logoutButtonStates[state]) {
                    button.style.setProperty(key, logoutButtonStates[state][key]);
                }
            }
        }
    
        // mouse hover listeners on button
        button.addEventListener('mouseenter', () => {
            if (button.state === 'default') {
                updateButtonState(button, 'hover');
            }
        });
        
        button.addEventListener('mouseleave', () => {
            if (button.state === 'hover') {
                updateButtonState(button, 'default');
            }
        });
    
        // click listener on button
        button.addEventListener('click', (e) => {
            e.preventDefault();
            
            const isLoggedIn = isUserLoggedIn();
            console.log('Button clicked. Logged in:', isLoggedIn);
            
            if (isLoggedIn) {
                // User is logged in - perform logout animation
                if (button.state === 'default' || button.state === 'hover') {
                    button.classList.add('clicked');
                    updateButtonState(button, 'walking1');
                    setTimeout(() => {
                        button.classList.add('door-slammed');
                        updateButtonState(button, 'walking2');
                        setTimeout(() => {
                            button.classList.add('falling');
                            updateButtonState(button, 'falling1');
                            setTimeout(() => {
                                updateButtonState(button, 'falling2');
                                setTimeout(() => {
                                    updateButtonState(button, 'falling3');
                                    setTimeout(() => {
                                        button.classList.remove('clicked');
                                        button.classList.remove('door-slammed');
                                        button.classList.remove('falling');
                                        updateButtonState(button, 'default');
                                        
                                        // Redirect to logout page after animation completes
                                        window.location.href = 'logout.php';
                                    }, 1000);
                                }, logoutButtonStates['falling2']['--walking-duration']);
                            }, logoutButtonStates['falling1']['--walking-duration']);
                        }, logoutButtonStates['walking2']['--figure-duration']);
                    }, logoutButtonStates['walking1']['--figure-duration']);
                }
            } else {
                // User is not logged in - redirect to login page immediately
                console.log('Redirecting to login.php');
                window.location.href = 'login.php';
            }
        });
    });
});

// ... keep your existing logoutButtonStates object as is ...