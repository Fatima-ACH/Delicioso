<?php
// get-orders.php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Include your existing database connection
require_once 'dbconnect.php';

try {
    // Get orders from database
    $query = "SELECT * FROM orders ORDER BY created_at DESC";
    $result = $db->query($query);
    
    $orders = [];
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Decode JSON items
            $row['items'] = json_decode($row['items'], true);
            $orders[] = $row;
        }
    }
    
    echo json_encode(['success' => true, 'orders' => $orders]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

$db->close();
?>