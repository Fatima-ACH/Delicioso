// products.js - COMPLETE FIXED VERSION

// ===== PRODUCTS DATABASE =====
const productsList = [
  /* ---------- CHEESECAKES ---------- */
  {
      id: "cheesecake-lotus",
      category: "cheesecake",
      name: "Lotus Cheesecake",
      price: 3,
      image:"lotuscheesecake.jpeg"
  },
  {
      id: "cheesecake-passionfruit", 
      category: "cheesecake",
      name: "Passion Fruit Cheesecake",
      price: 3,
      image: "passionfruitcheescake.jpeg"
  },
  { 
      id: "cheesecake-oreo",
      category: "cheesecake",
      name: "Oreo Cheesecake",
      price: 3,
      image: "oreocheescake.jpeg",
  },

  /* ---------- COOKIES  ---------- */
  {
    id: "cookie-normal",
    category: "cookie",
    name: "Classic Cookie (6pc)",
    price: 4.50,
    image: "cookies3flavors.jpeg",
  },
  {
    id: "cookie-redvelvet",
    category: "cookie",
    name: "Red Velvet Cookie (3pc)",
    price: 2.25,
    image: "Red Velvet Cookies.jpg",
  },
  {
    id: "cookie-chocolate-kinder",
    category: "cookie",
    name: "Chocolate Kinder Cookie (3pc)",
    price: 2.25,
    image: "chocolate kinder.jpg",
  },
  {
    id: "cookie-chocolate-nutella",
    category: "cookie",
    name: "Chocolate Nutella Cookie (3pc)",
    price: 2.25,
    image: "chocolate nutella.jpg",
  },

  /* ---------- BROWNIES ---------- */
  {
    id: "brownie-oreo",
    category: "brownie",
    name: "Oreo Brownie",
    price: 3,
    image: "oreobrownie.jpeg",
  },
  {
    id: "brownie-kinder",
    category: "brownie",
    name: "Kinder Brownie",
    price: 3,
    image: "kinderbrownie.jpeg",
  },
  {
    id: "brownie-lotus",
    category: "brownie",
    name: "Lotus Brownie",
    price: 3,
    image: "lotusbrownie.jpeg",
  },
  {
    id: "brownie-pistachio",
    category: "brownie",
    name: "Pistachio Brownie",
    price: 3,
    image: "pistachiobrownie.jpeg",
  },
  
  /* ---------- CAKES ---------- */
  {
    id: "cake-bounty",
    category: "cake",
    name: "Bounty Cake",
    price: 3,
    image: "bountycake.jpeg",
  },
  {
    id: "cake-tres-leches-large",
    category: "cake",
    name: "Tres Leches Cake (Large)",
    price: 3,
    image: "3lecheslarge.jpeg",
  },
  {
    id: "cake-tres-leches-small",
    category: "cake",
    name: "Tres Leches Cake (Small)",
    price: 1.5,
    image: "3lechessmall.jpeg",
  },
  {
    id: "cake-cocoberry",
    category: "cake",
    name: "Cocoberry Cake",
    price: 3,
    image: "cocoberrycake.jpeg",
  },
  {
    id: "cake-dubai-chocolate",
    category: "cake",
    name: "Dubai Chocolate Cake",
    price: 3,
    image: "dubaichocolatecake.jpeg",
  },
  {
    id: "cake-redvelvet",
    category: "cake",
    name: "Red Velvet Cake",
    price: 3,
    image: "redvelvet.jpeg",
  },
];

// ===== CART FUNCTIONS =====
function getSavedCart() {
  const text = localStorage.getItem("dessertCart");
  return text ? JSON.parse(text) : {};
}

function saveCart(cart) {
  localStorage.setItem("dessertCart", JSON.stringify(cart));
}

function updateCartIcon() {
  const cartIcon = document.getElementById("cartIcon");
  if (!cartIcon) return;
  
  const cart = getSavedCart();
  let total = 0;
  for (const id in cart) {
    total += cart[id];
  }
  cartIcon.setAttribute("data-totalitems", total);
}

// ===== ADD TO CART FUNCTION =====
function addToCart(productId, quantity = 1) {
  console.log("🛒 ADDING TO CART:", productId, "x", quantity);
  
  const cart = getSavedCart();
  cart[productId] = (cart[productId] || 0) + quantity;
  saveCart(cart);
  
  console.log("📦 CART UPDATED:", cart);
  updateCartIcon();
  
  // Show visual feedback
  const cartIcon = document.getElementById("cartIcon");
  if (cartIcon) {
    cartIcon.classList.add("shake");
    setTimeout(() => cartIcon.classList.remove("shake"), 400);
  }
  
  return true;
}

// ===== QUANTITY CONTROLS =====
function initializeProductQuantityControls() {
  console.log("🔄 Initializing quantity controls...");
  
  document.querySelectorAll(".dessert-item").forEach((item) => {
    const minus = item.querySelector(".qty-btn.minus");
    const plus = item.querySelector(".qty-btn.plus");
    const value = item.querySelector(".qty-value");
    const addBtn = item.querySelector(".dessert-add-btn");
    
    if (!minus || !plus || !value || !addBtn) return;

    let count = 1; // Start with 1 instead of 0
    value.textContent = count;

    plus.addEventListener("click", () => {
      count++;
      value.textContent = count;
      updateAddButtonText(addBtn, count);
    });

    minus.addEventListener("click", () => {
      if (count > 1) {
        count--;
        value.textContent = count;
        updateAddButtonText(addBtn, count);
      }
    });

    addBtn.addEventListener("click", () => {
      const productId = item.dataset.id;
      console.log("🎯 ADD BUTTON CLICKED:", productId, "x", count);
      
      if (count > 0) {
        const success = addToCart(productId, count);
        if (success) {
          // Show success feedback
          showAddToCartFeedback(addBtn);
          
          // Reset to 1 instead of 0
          count = 1;
          value.textContent = count;
          updateAddButtonText(addBtn, count);
        }
      }
    });
  });
}

function updateAddButtonText(button, quantity) {
  if (!button) return;
  
  if (quantity === 1) {
    button.textContent = "Add to Cart";
  } else {
    button.textContent = `Add ${quantity} to Cart`;
  }
}

function showAddToCartFeedback(button) {
  const originalText = button.textContent;
  button.textContent = "✓ Added!";
  button.style.background = "#4CAF50";
  button.style.color = "white";
  
  setTimeout(() => {
    button.textContent = originalText;
    button.style.background = "";
    button.style.color = "";
  }, 1500);
}

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', function() {
  console.log("🚀 Products.js loaded successfully!");
  console.log("📋 Products count:", productsList.length);
  
  initializeProductQuantityControls();
  updateCartIcon();
  
  // Test that functions are available
  console.log("✅ addToCart function:", typeof addToCart);
  console.log("✅ getSavedCart function:", typeof getSavedCart);
});

// ===== MAKE FUNCTIONS GLOBAL =====
window.productsList = productsList;
window.getSavedCart = getSavedCart;
window.saveCart = saveCart;
window.updateCartIcon = updateCartIcon;
window.addToCart = addToCart;
window.initializeProductQuantityControls = initializeProductQuantityControls;