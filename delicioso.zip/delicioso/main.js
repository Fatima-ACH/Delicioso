document.addEventListener("DOMContentLoaded", function () {
  /* =========================
     MENU TOGGLE (SIDE MENU)
  ========================== */

  const menuToggle   = document.getElementById("menuToggle");
  const slidingMenu  = document.getElementById("slidingMenu");
  const closeMenuBtn = document.getElementById("closeMenu");
  const menuOverlay  = document.getElementById("menuOverlay");

  function openMenu() {
    if (!slidingMenu || !menuOverlay) return;
    slidingMenu.classList.add("active");
    menuOverlay.classList.add("active");
    document.body.style.overflow = "hidden";
  }

  function closeMenu() {
    if (!slidingMenu || !menuOverlay) return;
    slidingMenu.classList.remove("active");
    menuOverlay.classList.remove("active");
    document.body.style.overflow = "auto";
  }

  if (menuToggle) {
    menuToggle.addEventListener("click", openMenu);
  }
  if (closeMenuBtn) {
    closeMenuBtn.addEventListener("click", closeMenu);
  }
  if (menuOverlay) {
    menuOverlay.addEventListener("click", closeMenu);
  }

  const sideMenuLinks = document.querySelectorAll(".menu-categories a");
  sideMenuLinks.forEach((link) => {
    link.addEventListener("click", closeMenu);
  });

  /* =========================
     LOGOUT BUTTON STATES
  ========================== */

  const logoutButtonStates = {
    default: {
      "--figure-duration": "100",
      "--transform-figure": "none",
      "--walking-duration": "100",
      "--transform-arm1": "none",
      "--transform-wrist1": "none",
      "--transform-arm2": "none",
      "--transform-wrist2": "none",
      "--transform-leg1": "none",
      "--transform-calf1": "none",
      "--transform-leg2": "none",
      "--transform-calf2": "none",
    },
    hover: {
      "--figure-duration": "100",
      "--transform-figure": "translateX(1.5px)",
      "--walking-duration": "100",
      "--transform-arm1": "rotate(-5deg)",
      "--transform-wrist1": "rotate(-15deg)",
      "--transform-arm2": "rotate(5deg)",
      "--transform-wrist2": "rotate(6deg)",
      "--transform-leg1": "rotate(-10deg)",
      "--transform-calf1": "rotate(5deg)",
      "--transform-leg2": "rotate(20deg)",
      "--transform-calf2": "rotate(-20deg)",
    },
    walking1: {
      "--figure-duration": "300",
      "--transform-figure": "translateX(11px)",
      "--walking-duration": "300",
      "--transform-arm1":
        "translateX(-4px) translateY(-2px) rotate(120deg)",
      "--transform-wrist1": "rotate(-5deg)",
      "--transform-arm2": "translateX(4px) rotate(-110deg)",
      "--transform-wrist2": "rotate(-5deg)",
      "--transform-leg1": "translateX(-3px) rotate(80deg)",
      "--transform-calf1": "rotate(-30deg)",
      "--transform-leg2": "translateX(4px) rotate(-60deg)",
      "--transform-calf2": "rotate(20deg)",
    },
    walking2: {
      "--figure-duration": "400",
      "--transform-figure": "translateX(17px)",
      "--walking-duration": "300",
      "--transform-arm1": "rotate(60deg)",
      "--transform-wrist1": "rotate(-15deg)",
      "--transform-arm2": "rotate(-45deg)",
      "--transform-wrist2": "rotate(6deg)",
      "--transform-leg1": "rotate(-5deg)",
      "--transform-calf1": "rotate(10deg)",
      "--transform-leg2": "rotate(10deg)",
      "--transform-calf2": "rotate(-20deg)",
    },
    falling1: {
      "--figure-duration": "1600",
      "--walking-duration": "400",
      "--transform-arm1": "rotate(-60deg)",
      "--transform-wrist1": "none",
      "--transform-arm2": "rotate(30deg)",
      "--transform-wrist2": "rotate(120deg)",
      "--transform-leg1": "rotate(-30deg)",
      "--transform-calf1": "rotate(-20deg)",
      "--transform-leg2": "rotate(20deg)",
    },
    falling2: {
      "--walking-duration": "300",
      "--transform-arm1": "rotate(-100deg)",
      "--transform-arm2": "rotate(-60deg)",
      "--transform-wrist2": "rotate(60deg)",
      "--transform-leg1": "rotate(80deg)",
      "--transform-calf1": "rotate(20deg)",
      "--transform-leg2": "rotate(-60deg)",
    },
    falling3: {
      "--walking-duration": "500",
      "--transform-arm1": "rotate(-30deg)",
      "--transform-wrist1": "rotate(40deg)",
      "--transform-arm2": "rotate(50deg)",
      "--transform-wrist2": "none",
      "--transform-leg1": "rotate(-30deg)",
      "--transform-leg2": "rotate(20deg)",
      "--transform-calf2": "none",
    },
  };

  /* =========================
     LOGIN STATE HANDLING
  ========================== */

  function checkLoginStatus() {
    const loggedInButtons  = document.getElementById("loggedInButtons");
    const loggedOutButtons = document.getElementById("loggedOutButtons");
    const logoutButton     = document.querySelector(".logoutButton");

    const bodyLoggedIn = document.body.getAttribute("data-logged-in");
    const isLoggedIn   = bodyLoggedIn === "true";

    if (isLoggedIn) {
      if (loggedInButtons)  loggedInButtons.style.display  = "flex";
      if (loggedOutButtons) loggedOutButtons.style.display = "none";
      if (logoutButton) {
        const buttonText = logoutButton.querySelector(".button-text");
        if (buttonText) buttonText.textContent = "Logout";
      }
    } else {
      if (loggedInButtons)  loggedInButtons.style.display  = "none";
      if (loggedOutButtons) loggedOutButtons.style.display = "flex";
    }
  }

  function initLogoutButton() {
    const logoutButton = document.querySelector(".logoutButton");
    if (!logoutButton) return;

    logoutButton.state = "default";

    function updateButtonState(button, state) {
      const cfg = logoutButtonStates[state];
      if (!cfg) return;
      button.state = state;
      for (const key in cfg) {
        button.style.setProperty(key, cfg[key]);
      }
    }

    logoutButton.addEventListener("mouseenter", () => {
      if (logoutButton.state === "default") {
        updateButtonState(logoutButton, "hover");
      }
    });

    logoutButton.addEventListener("mouseleave", () => {
      if (logoutButton.state === "hover") {
        updateButtonState(logoutButton, "default");
      }
    });

    logoutButton.addEventListener("click", (e) => {
      e.preventDefault();

      const isLoggedIn =
        document.body.getAttribute("data-logged-in") === "true";

      if (!isLoggedIn) return;

      if (logoutButton.state === "default" || logoutButton.state === "hover") {
        logoutButton.classList.add("clicked");
        updateButtonState(logoutButton, "walking1");

        setTimeout(() => {
          logoutButton.classList.add("door-slammed");
          updateButtonState(logoutButton, "walking2");

          setTimeout(() => {
            logoutButton.classList.add("falling");
            updateButtonState(logoutButton, "falling1");

            setTimeout(() => {
              updateButtonState(logoutButton, "falling2");

              setTimeout(() => {
                updateButtonState(logoutButton, "falling3");

                setTimeout(() => {
                  logoutButton.classList.remove("clicked", "door-slammed", "falling");
                  updateButtonState(logoutButton, "default");
                  window.location.href = "logout.php";
                }, 1000);
              }, Number(logoutButtonStates.falling2["--walking-duration"]));
            }, Number(logoutButtonStates.falling1["--walking-duration"]));
          }, Number(logoutButtonStates.walking2["--figure-duration"]));
        }, Number(logoutButtonStates.walking1["--figure-duration"]));
      }
    });
  }

  /* =========================
     CART BADGE
  ========================== */

  function updateCartBadge() {
    const raw  = localStorage.getItem("dessertCart");
    const cart = raw ? JSON.parse(raw) : {};
    let totalItems = 0;

    for (const id in cart) {
      totalItems += cart[id];
    }

    const cartBadges = document.querySelectorAll(".cart-badge");
    cartBadges.forEach((badge) => {
      badge.textContent = totalItems;
      badge.style.display = totalItems > 0 ? "block" : "none";
    });
  }

  /* =========================
     SIMPLE SLIDERS (2 stacked)
  ========================== */

  function initSlider(wrapperId) {
    const wrapper = document.getElementById(wrapperId);
    if (!wrapper) return;

    const slides = wrapper.querySelectorAll(".slider-slide");
    const prevBtn = wrapper.querySelector(".slider-prev");
    const nextBtn = wrapper.querySelector(".slider-next");

    const dotsContainer = document.querySelector(
      `.slider-dots[data-slider-dots="${wrapperId}"]`
    );
    const dots = dotsContainer ? dotsContainer.querySelectorAll(".dot") : [];

    let current = 0;

    function showSlide(index) {
      if (!slides.length) return;
      current = (index + slides.length) % slides.length; // wrap

      slides.forEach((slide, i) => {
        slide.classList.toggle("active", i === current);
      });

      dots.forEach((dot, i) => {
        dot.classList.toggle("active", i === current);
      });
    }

    if (prevBtn) {
      prevBtn.addEventListener("click", () => {
        showSlide(current - 1);
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener("click", () => {
        showSlide(current + 1);
      });
    }

    dots.forEach((dot) => {
      const idx = parseInt(dot.getAttribute("data-index"), 10);
      if (!isNaN(idx)) {
        dot.addEventListener("click", () => showSlide(idx));
      }
    });

    showSlide(0);
  }

  /* =========================
     INIT
  ========================== */

  checkLoginStatus();

  if (document.body.getAttribute("data-logged-in") === "true") {
    initLogoutButton();
  }

  updateCartBadge();

  initSlider("slider1");
  initSlider("slider2");
});

const slider = document.getElementById("bestSlider");
const dots = document.querySelectorAll("#bestDots .dot");

// ===== HORIZONTAL SCROLL + DOTS FOR BOTH SLIDERS =====

function initScrollDots(sliderId, dotsId) {
  const slider = document.getElementById(sliderId);
  const dots = document.querySelectorAll(`#${dotsId} .dot`);

  if (!slider || !dots.length) return;

  slider.addEventListener("scroll", () => {
    const cards = slider.querySelectorAll(".product-card");
    if (!cards.length) return;

    const sliderRect = slider.getBoundingClientRect();
    const sliderCenter = sliderRect.left + sliderRect.width / 2;

    let closestIndex = 0;
    let smallestDist = Infinity;

    cards.forEach((card, index) => {
      const rect = card.getBoundingClientRect();
      const cardCenter = rect.left + rect.width / 2;
      const dist = Math.abs(cardCenter - sliderCenter);

      if (dist < smallestDist) {
        smallestDist = dist;
        closestIndex = index;
      }
    });

    dots.forEach((dot, i) => {
      dot.classList.toggle("active", i === closestIndex);
    });
  });
}

// call for both sliders
initScrollDots("bestSlider", "bestDots");
initScrollDots("giftSlider", "giftDots");

