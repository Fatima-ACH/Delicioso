<?php
// update-order-status.php - FIXED VERSION
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include your existing database connection
require_once 'dbconnect.php';

// Get data from either FormData or raw JSON
if (!empty($_POST['orderData'])) {
    // Data sent as FormData
    $data = json_decode($_POST['orderData'], true);
} else {
    // Data sent as raw JSON
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
}

// Log for debugging
error_log("Received data: " . print_r($data, true));

if (!$data || !isset($data['orderId']) || !isset($data['status'])) {
    // Try alternative parameter names
    if (isset($_POST['orderId']) && isset($_POST['status'])) {
        $data = [
            'orderId' => $_POST['orderId'],
            'status' => $_POST['status']
        ];
    } else {
        error_log("Missing required fields");
        echo json_encode(['success' => false, 'message' => 'Invalid data: orderId and status are required. Received: ' . print_r($data, true)]);
        exit;
    }
}

$orderId = $data['orderId'];
$status = $data['status'];

error_log("Updating order: $orderId to status: $status");

try {
    // First, check if the order exists
    $checkQuery = "SELECT order_id FROM orders WHERE order_id = ?";
    $checkStmt = $db->prepare($checkQuery);
    $checkStmt->bind_param("s", $orderId);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    
    if ($checkResult->num_rows === 0) {
        error_log("Order not found: $orderId");
        echo json_encode(['success' => false, 'message' => 'Order not found: ' . $orderId]);
        exit;
    }
    
    $checkStmt->close();
    
    // Update the order status
    $query = "UPDATE orders SET status = ? WHERE order_id = ?";
    $stmt = $db->prepare($query);
    
    if (!$stmt) {
        throw new Exception('Prepare failed: ' . $db->error);
    }
    
    $stmt->bind_param("ss", $status, $orderId);
    
    if ($stmt->execute()) {
        $affectedRows = $stmt->affected_rows;
        error_log("Update successful. Affected rows: $affectedRows");
        
        echo json_encode(['success' => true, 'message' => 'Order status updated successfully']);
    } else {
        throw new Exception('Execute failed: ' . $stmt->error);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    error_log("Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}

$db->close();
?>