// Get cart items from localStorage
function getCartItems() {
    const cart = JSON.parse(localStorage.getItem('dessertCart') || '{}');
    const productsList = [
        { id: "cheesecake-lotus", name: "Lotus Cheesecake", price: 3 },
        { id: "cheesecake-passionfruit", name: "Passion Fruit Cheesecake", price: 3 },
        { id: "cheesecake-oreo", name: "Oreo Cheesecake", price: 3 },
        { id: "cookie-normal", name: "Classic Cookie (6pc)", price: 4.50 },
        { id: "cookie-redvelvet", name: "Red Velvet Cookie (3pc)", price: 2.25 },
        { id: "cookie-chocolate-kinder", name: "Chocolate Kinder Cookie (3pc)", price: 2.25 },
        { id: "cookie-chocolate-nutella", name: "Chocolate Nutella Cookie (3pc)", price: 2.25 },
        { id: "brownie-oreo", name: "Oreo Brownie", price: 3 },
        { id: "brownie-kinder", name: "Kinder Brownie", price: 3 },
        { id: "brownie-lotus", name: "Lotus Brownie", price: 3 },
        { id: "brownie-pistachio", name: "Pistachio Brownie", price: 3 },
        { id: "cake-bounty", name: "Bounty Cake", price: 3 },
        { id: "cake-tres-leches-large", name: "Tres Leches Cake (Large)", price: 3 },
        { id: "cake-tres-leches-small", name: "Tres Leches Cake (Small)", price: 1.5 },
        { id: "cake-cocoberry", name: "Cocoberry Cake", price: 3 },
        { id: "cake-dubai-chocolate", name: "Dubai Chocolate Cake", price: 3 },
        { id: "cake-redvelvet", name: "Red Velvet Cake", price: 3 }
    ];

    const orderItems = [];
    
    productsList.forEach(product => {
        const quantity = cart[product.id] || 0;
        if (quantity > 0) {
            orderItems.push({
                id: product.id,
                name: product.name,
                price: product.price,
                quantity: quantity
            });
        }
    });
    
    return orderItems;
}

// Get preorder settings from localStorage
function getPreorderSettings() {
    const settings = JSON.parse(localStorage.getItem('preorderSettings') || '{}');
    
    // Default values if no preorder settings found
    const defaultSettings = {
        isDelivery: false,
        location: '',
        deliveryFee: 0,
        date: '',
        time: '',
        isPreorder: false
    };
    
    return { ...defaultSettings, ...settings };
}

let orderItems = [];
let preorderSettings = {};

function goBack() {
    window.location.href = 'preorder.html';
}

function calculateOrderTotals() {
    const subtotal = orderItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const deliveryFee = preorderSettings.isDelivery ? preorderSettings.deliveryFee : 0;
    const total = subtotal + deliveryFee;
    return { subtotal, deliveryFee, total };
}

function validateLebanesePhoneNumber(phone) {
    const digits = phone.replace(/\D/g, '');
    if (digits.length !== 8) return false;
    const validPrefixes = ['03', '70', '71', '76', '78', '79', '81'];
    const prefix = digits.substring(0, 2);
    return validPrefixes.includes(prefix);
}

function updatePreorderSummaryDisplay() {
    const preorderSummary = document.getElementById('preorderSummary');
    const deliveryType = document.getElementById('deliveryType');
    const deliveryLocation = document.getElementById('deliveryLocation');
    const deliveryDate = document.getElementById('deliveryDate');
    const deliveryTime = document.getElementById('deliveryTime');
    const deliveryFee = document.getElementById('deliveryFeeAmount');
    
    if (preorderSettings.isPreorder) {
        preorderSummary.style.display = 'block';
        
        if (preorderSettings.isDelivery) {
            deliveryType.textContent = 'Delivery';
            deliveryLocation.textContent = `Location: ${preorderSettings.location === 'manara' ? 'Al Manara' : 'West Bekaa'}`;
            deliveryLocation.style.display = 'block';
        } else {
            deliveryType.textContent = 'Pickup';
            deliveryLocation.style.display = 'none';
        }
        
        if (preorderSettings.date) {
            const formattedDate = formatDeliveryDate(preorderSettings.date);
            deliveryDate.textContent = `Date: ${formattedDate}`;
            deliveryDate.style.display = 'block';
        } else {
            deliveryDate.style.display = 'none';
        }
        
        if (preorderSettings.time) {
            deliveryTime.textContent = `Time: ${preorderSettings.time}`;
            deliveryTime.style.display = 'block';
        } else {
            deliveryTime.style.display = 'none';
        }
        
        deliveryFee.textContent = `$${preorderSettings.deliveryFee.toFixed(2)}`;
    } else {
        preorderSummary.style.display = 'none';
        // Default delivery fee for non-preorder
        deliveryFee.textContent = '$2.00';
    }
}

function updateOrderDisplay() {
    const orderItemsContainer = document.getElementById('orderItems');
    const { subtotal, deliveryFee, total } = calculateOrderTotals();
    
    orderItemsContainer.innerHTML = orderItems.map(item => `
        <div class="order-item">
            <div class="item-details">
                <div>
                    <div class="item-name">${item.name}</div>
                    <div class="item-price">$${item.price.toFixed(2)}</div>
                </div>
                <div class="item-qty">Qty: ${item.quantity}</div>
            </div>
        </div>
    `).join('');
    
    document.getElementById('orderSubtotal').textContent = `$${subtotal.toFixed(2)}`;
    document.getElementById('orderTotal').textContent = `$${total.toFixed(2)}`;
    document.getElementById('placeOrderBtn').textContent = `Place Order - $${total.toFixed(2)}`;
    
    // Update preorder summary display
    updatePreorderSummaryDisplay();
}

function getProductEmoji(productId) {
    if (productId.includes('cheesecake')) return '🍰';
    if (productId.includes('cookie')) return '🍪';
    if (productId.includes('brownie')) return '🧁';
    if (productId.includes('cake')) return '🎂';
    return '🍽️';
}

function formatDeliveryDate(dateString) {
    if (!dateString) return 'ASAP';
    
    const date = new Date(dateString + 'T00:00:00');
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    return date.toLocaleDateString('en-US', options);
}

function saveOrderToAdmin(fullName, phoneNumber, email, deliveryAddress, specialInstructions) {
    console.log('💾 Saving order to admin...');
    
    const { subtotal, deliveryFee, total } = calculateOrderTotals();
    const orderId = 'DEL' + Date.now();
    
    const newOrder = {
        id: orderId,
        timestamp: new Date().toISOString(),
        status: 'new',
        type: preorderSettings.isPreorder ? 'preorder' : 'regular',
        customer: {
            name: fullName,
            phone: phoneNumber,
            email: email,
            address: deliveryAddress,
            instructions: specialInstructions
        },
        items: orderItems.map(item => ({
            id: item.id,
            name: item.name,
            price: item.price,
            quantity: item.quantity,
            emoji: getProductEmoji(item.id),
            itemTotal: item.price * item.quantity
        })),
        preorder: preorderSettings.isPreorder ? {
            isDelivery: preorderSettings.isDelivery,
            location: preorderSettings.location,
            date: preorderSettings.date,
            time: preorderSettings.time,
            deliveryFee: preorderSettings.deliveryFee
        } : null,
        subtotal: subtotal,
        deliveryFee: deliveryFee,
        total: total
    };
    
    console.log('📦 New order:', newOrder);
    
    let existingOrders = [];
    try {
        const stored = localStorage.getItem('deliciosoOrders');
        if (stored) {
            existingOrders = JSON.parse(stored);
            console.log('📋 Found existing orders:', existingOrders.length);
        }
    } catch (e) {
        console.log('❌ No existing orders or parse error, starting fresh');
        existingOrders = [];
    }
    
    existingOrders.push(newOrder);
    localStorage.setItem('deliciosoOrders', JSON.stringify(existingOrders));
    
    console.log('✅ Order saved! Total orders now:', existingOrders.length);
    
    return orderId;
}

async function sendOrderToServer(orderData) {
    try {
        console.log('📤 Sending order to server...');
        
        const formData = new FormData();
        formData.append('orderData', JSON.stringify(orderData));
        
        const response = await fetch('process-order.php', {
            method: 'POST',
            body: formData
        });

        const responseText = await response.text();
        console.log('📨 Server response:', responseText);

        let result;
        try {
            result = JSON.parse(responseText);
        } catch (parseError) {
            console.error('❌ Invalid JSON response:', responseText);
            throw new Error('Server returned invalid response');
        }

        if (result.success) {
            console.log('✅ Order saved to database!');
            return result;
        } else {
            throw new Error(result.message || 'Failed to process order');
        }
    } catch (error) {
        console.error('❌ Server request failed:', error);
        throw error;
    }
}

async function placeOrder() {
    console.log('=== PLACING ORDER ===');
    
    const fullName = document.getElementById('fullName').value.trim();
    const phoneNumber = document.getElementById('phoneNumber').value.trim();
    const email = document.getElementById('email').value.trim();
    const deliveryAddress = document.getElementById('deliveryAddress').value.trim();
    const specialInstructions = document.getElementById('specialInstructions').value.trim();

    // Validation
    if (!fullName || !phoneNumber || !email || !deliveryAddress) {
        alert('Please fill in all required fields');
        return;
    }

    if (!validateLebanesePhoneNumber(phoneNumber)) {
        alert('Please enter a valid Lebanese phone number (8 digits, valid Lebanese prefix)');
        return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert('Please enter a valid email address');
        return;
    }

    // Show loading
    const placeOrderBtn = document.getElementById('placeOrderBtn');
    const loadingSpinner = document.getElementById('loadingSpinner');
    placeOrderBtn.style.display = 'none';
    loadingSpinner.style.display = 'block';

    try {
        // Save order to localStorage
        const orderId = saveOrderToAdmin(fullName, phoneNumber, email, deliveryAddress, specialInstructions);
        
        // Prepare data for email
        const { subtotal, deliveryFee, total } = calculateOrderTotals();
        const orderData = {
            fullName: fullName,
            phone: phoneNumber,
            email: email,
            deliveryAddress: deliveryAddress,
            specialInstructions: specialInstructions || 'None',
            items: orderItems,
            preorder: preorderSettings.isPreorder ? preorderSettings : null,
            subtotal: subtotal,
            deliveryFee: deliveryFee,
            total: total,
            orderId: orderId
        };

        // Try to send emails
        let emailResult = null;
        try {
            emailResult = await sendOrderToServer(orderData);
            console.log('✅ Emails sent successfully');
        } catch (emailError) {
            console.log('⚠️ Email failed but order continues:', emailError.message);
        }
        
        // Show success message
        loadingSpinner.style.display = 'none';
        document.getElementById('successMessage').style.display = 'block';
        document.getElementById('orderId').textContent = orderId;
        document.getElementById('customerEmail').textContent = email;
        
        // Update delivery info in success message
        const deliveryInfoElement = document.getElementById('deliveryInfo');
        if (preorderSettings.isPreorder && preorderSettings.date && preorderSettings.time) {
            const formattedDate = formatDeliveryDate(preorderSettings.date);
            deliveryInfoElement.innerHTML = `
                <strong>${preorderSettings.isDelivery ? 'Delivery' : 'Pickup'} scheduled for:</strong><br>
                ${formattedDate} at ${preorderSettings.time}<br>
                ${preorderSettings.isDelivery ? `Location: ${preorderSettings.location === 'manara' ? 'Al Manara' : 'West Bekaa'}` : 'Pickup at our kitchen'}
            `;
        } else {
            deliveryInfoElement.innerHTML = `<strong>Delivery:</strong> ASAP (within 1-2 hours)`;
        }
        
        // Show appropriate message based on email success
        if (emailResult && emailResult.customerEmailSent) {
            document.getElementById('emailConfirmation').style.display = 'block';
        } else {
            document.getElementById('emailWarning').style.display = 'block';
        }
        
        // Clear cart and preorder settings
        localStorage.removeItem('dessertCart');
        localStorage.removeItem('preorderSettings');
        
        console.log('🎉 ORDER SUCCESS! Order ID:', orderId);
        
    } catch (error) {
        console.error('💥 Order failed:', error);
        alert('Order failed: ' + error.message);
        loadingSpinner.style.display = 'none';
        placeOrderBtn.style.display = 'block';
    }
}

document.addEventListener('DOMContentLoaded', function() {
    console.log('🛒 Checkout page loaded');
    
    orderItems = getCartItems();
    preorderSettings = getPreorderSettings();
    
    console.log('📅 Preorder settings:', preorderSettings);
    
    if (orderItems.length === 0) {
        alert('Your cart is empty! Redirecting to menu...');
        window.location.href = 'menu.html';
        return;
    }
    
    updateOrderDisplay();
});