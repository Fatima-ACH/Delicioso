<?php
include("dbconnect.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Debug: Check what's being posted
    error_log("POST data: " . print_r($_POST, true));

    $first = trim($_POST["first_name"]);
    $last = trim($_POST["last_name"]);
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $password = $_POST["password"];
    $confirm = $_POST["confirm_password"];

    // Debug: Check individual values
    error_log("Username: $username, Email: $email");

    // 0. Confirm password check
    if ($password !== $confirm) {
        $message = "❌ Passwords do not match.";
    } else {
        // 1. Check username
        $checkUser = $db->prepare("SELECT id FROM users WHERE username = ?");
        $checkUser->bind_param("s", $username);
        $checkUser->execute();
        $checkUser->store_result();

        if ($checkUser->num_rows > 0) {
            $message = "❌ Username already exists.";
        } else {
            // 2. Check email
            $checkEmail = $db->prepare("SELECT id FROM users WHERE email = ?");
            $checkEmail->bind_param("s", $email);
            $checkEmail->execute();
            $checkEmail->store_result();

            if ($checkEmail->num_rows > 0) {
                $message = "❌ Email already exists.";
            } else {
                // 3. Insert new user
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                
                $query = "INSERT INTO users (first_name, last_name, username, email, password) 
                          VALUES (?, ?, ?, ?, ?)";

                $stmt = $db->prepare($query);
                $stmt->bind_param("sssss", $first, $last, $username, $email, $hashedPassword);

                if ($stmt->execute()) {
                    header("Location: login.php?registered=1");
                    exit;
                } else {
                    $message = "❌ Something went wrong: " . $db->error;
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Delicioso</title>
    <link rel="icon" href="delicioso.png">
    <link rel="stylesheet" href="s.css">
    <style>
        /* Mobile fix only - keeps your exact design */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
                height: auto;
                min-height: 100vh;
                align-items: center;
            }
            .form-wrapper {
                width: 100%;
                max-width: 340px;
                margin: 0 auto;
            }
            body, html {
                overflow: auto;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="background-image"></div>
    <div class="form-wrapper">
        <h1 class="logo">Delicioso</h1>

        <?php if ($message != "") echo "<p style='color:red;text-align:center;margin-bottom:20px;'>$message</p>"; ?>

        <form action="register.php" method="POST" class="form active">
            <h2>Sign Up</h2>

            <label for="first_name">First Name</label>
            <input type="text" id="first_name" name="first_name" required>

            <label for="last_name">Last Name</label>
            <input type="text" id="last_name" name="last_name" required>

            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>

            <label for="confirm_password">Confirm Password</label>
            <input type="password" id="confirm_password" name="confirm_password" required>

            <div id="password-match-message"></div>

            <button class="btn" type="submit">Sign Up</button>

        
            <p>Already have an account?
                <a href="login.php">Log In</a>
            </p>
        </form>
    </div>
</div>
<script src="login.js"></script>
</body>
</html>