<?php
require_once 'oauth-config.php';

session_start();
$state = bin2hex(random_bytes(16));
$_SESSION['oauth_state'] = $state;

$authUrl = 'https://www.facebook.com/v19.0/dialog/oauth?' . http_build_query([
    'client_id' => FACEBOOK_APP_ID,
    'redirect_uri' => FACEBOOK_REDIRECT_URI,
    'scope' => 'email,public_profile',
    'response_type' => 'code',
    'state' => $state
]);

header('Location: ' . $authUrl);
exit;
?>