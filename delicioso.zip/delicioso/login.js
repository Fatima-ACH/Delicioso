// Toggle between login and register forms
document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');
  const showRegisterLink = document.getElementById('show-register');
  const showLoginLink = document.getElementById('show-login');

  const passwordInput = document.getElementById('reg-password');
  const confirmPasswordInput = document.getElementById('confirm-password');
  const passwordMatchMessage = document.getElementById('password-match-message');

  if (showRegisterLink) {
    showRegisterLink.addEventListener('click', e => {
      e.preventDefault();
      if (loginForm) loginForm.classList.remove('active');
      if (registerForm) registerForm.classList.add('active');
      if (passwordMatchMessage) passwordMatchMessage.textContent = "";
      if (passwordInput) passwordInput.value = "";
      if (confirmPasswordInput) confirmPasswordInput.value = "";
    });
  }

  if (showLoginLink) {
    showLoginLink.addEventListener('click', e => {
      e.preventDefault();
      if (registerForm) registerForm.classList.remove('active');
      if (loginForm) loginForm.classList.add('active');
    });
  }

  if (confirmPasswordInput && passwordInput && passwordMatchMessage) {
    confirmPasswordInput.addEventListener('input', () => {
      if (confirmPasswordInput.value === "") {
        passwordMatchMessage.textContent = "";
        return;
      }
      if (confirmPasswordInput.value === passwordInput.value) {
        passwordMatchMessage.style.color = 'green';
        passwordMatchMessage.textContent = "Passwords match ✓";
      } else {
        passwordMatchMessage.style.color = 'red';
        passwordMatchMessage.textContent = "Passwords do not match ✗";
      }
    });
  }
});
