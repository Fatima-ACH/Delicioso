// Best seller product IDs (must exist in productsList from products.js)
const bestSellerIds = [
  "cheesecake-lotus",
  "cheesecake-oreo",
  "brownie-lotus",
  "cake-tres-leches-large",
  "cake-redvelvet",
  "cookie-normal",
];

// Display best sellers
function displayBestSellers() {
  const bestsellersGrid = document.getElementById("bestsellersGrid");
  if (!bestsellersGrid || !window.productsList) return;

  bestsellersGrid.innerHTML = "";

  const bestSellers = productsList.filter((product) =>
    bestSellerIds.includes(product.id)
  );

  const rankings = ["🏆", "🥈", "🥉", "💫", "⭐", "🔥"];

  bestSellers.forEach((product, index) => {
    const rankingEmoji = rankings[index] || "⭐";

    const bestsellerCard = document.createElement("div");
    bestsellerCard.className = "bestseller-card";

    bestsellerCard.innerHTML = `
      <div class="bestseller-image">
        <img src="${product.image}" alt="${product.name}"
          onerror="this.src='https://via.placeholder.com/300x200/EBDDA8/522922?text=Best+Seller'">
      </div>
      <div class="bestseller-content">
        <h3 class="bestseller-title">
          <span>${rankingEmoji}</span> ${product.name} ${product.emoji || ""}
        </h3>
        <p class="bestseller-description">${product.description || ""}</p>
        <div class="bestseller-price">$${product.price.toFixed(2)}</div>
        <div class="quantity-controls">
          <button class="qty-btn minus">−</button>
          <span class="qty-value">1</span>
          <button class="qty-btn plus">+</button>
        </div>
        <button class="dessert-add-btn" data-product-id="${product.id}">
          <i class="fas fa-cart-plus"></i> Add to Cart
        </button>
      </div>
    `;

    bestsellersGrid.appendChild(bestsellerCard);
  });

  attachEventListeners();
}

// Attach event listeners to quantity buttons + add-to-cart
function attachEventListeners() {
  // Quantity controls
  document.querySelectorAll(".qty-btn").forEach((button) => {
    button.addEventListener("click", function () {
      const container = this.closest(".quantity-controls");
      const valueElement = container.querySelector(".qty-value");
      let value = parseInt(valueElement.textContent, 10);

      if (this.classList.contains("plus")) {
        value++;
      } else if (this.classList.contains("minus") && value > 1) {
        value--;
      }

      valueElement.textContent = value;
    });
  });

  // Add to cart buttons
  document.querySelectorAll(".dessert-add-btn").forEach((button) => {
    button.addEventListener("click", function () {
      const productCard = this.closest(".bestseller-card");
      const title = productCard
        .querySelector(".bestseller-title")
        .textContent.trim();
      const priceText = productCard
        .querySelector(".bestseller-price")
        .textContent.trim();
      const quantityText = productCard
        .querySelector(".qty-value")
        .textContent.trim();
      const productId = this.getAttribute("data-product-id");

      const product = productsList.find((p) => p.id === productId);
      if (!product) return;

      const quantity = parseInt(quantityText, 10) || 1;

      alert(`Added to cart: ${quantity}x ${title} - ${priceText}`);

      // reset quantity
      productCard.querySelector(".qty-value").textContent = "1";

      // unified cart storage: dessertCart
      addToCart(product, quantity);
    });
  });
}

// Add item to cart (same storage as other pages)
function addToCart(product, quantity) {
  const stored = localStorage.getItem("dessertCart");
  const cart = stored ? JSON.parse(stored) : {};

  const currentQty = cart[product.id] || 0;
  cart[product.id] = currentQty + quantity;

  localStorage.setItem("dessertCart", JSON.stringify(cart));

  console.log("Cart updated:", cart);
}

// Star rating system
function setupStarRating() {
  const stars = document.querySelectorAll(".star");
  const starContainer = document.getElementById("starRating");
  const reviewForm = document.getElementById("reviewForm");
  const reviewText = document.getElementById("reviewText");

  if (!stars.length || !starContainer || !reviewForm || !reviewText) return;

  let currentRating = 0;

  function updateStars(rating) {
    stars.forEach((star) => {
      const starRating = parseInt(star.getAttribute("data-rating"), 10);
      if (starRating <= rating) {
        star.classList.add("active");
      } else {
        star.classList.remove("active");
      }
    });
  }

  stars.forEach((star) => {
    star.addEventListener("click", function () {
      currentRating = parseInt(this.getAttribute("data-rating"), 10);
      updateStars(currentRating);
    });

    star.addEventListener("mouseover", function () {
      const rating = parseInt(this.getAttribute("data-rating"), 10);
      updateStars(rating);
    });
  });

  starContainer.addEventListener("mouseleave", function () {
    updateStars(currentRating);
  });

  reviewForm.addEventListener("submit", function (e) {
    e.preventDefault();

    if (currentRating === 0) {
      alert("Please select a rating.");
      return;
    }

    const text = reviewText.value.trim();
    if (!text) {
      alert("Please write a review.");
      return;
    }

    alert("Thank you for your review! We appreciate your feedback.");

    reviewForm.reset();
    currentRating = 0;
    updateStars(0);
  });
}

// Initialize once DOM is ready
document.addEventListener("DOMContentLoaded", function () {
  displayBestSellers();
  setupStarRating();
});
