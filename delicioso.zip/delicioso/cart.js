// cart.js - UPDATED VERSION

// ===== CART STORAGE HELPERS =====
function getSavedCart() {
  const text = localStorage.getItem("dessertCart");
  if (!text) return {};
  return JSON.parse(text);
}

function saveCart(cart) {
  localStorage.setItem("dessertCart", JSON.stringify(cart));
}

// ===== DOM ELEMENTS =====
const cartItemsContainer = document.getElementById("cartItems");
const subtotalSpan = document.getElementById("subtotal");
const totalSpan = document.getElementById("total");
const itemCountText = document.getElementById("itemCount");

// ===== RENDER CART ITEMS =====
function renderCartItems() {
  console.log("🛒 Rendering cart items...");
  
  const cart = getSavedCart();
  const customProducts = JSON.parse(localStorage.getItem('customProducts') || '{}');
  
  console.log("📦 Cart data:", cart);
  console.log("🎨 Custom products:", customProducts);
  console.log("📋 Available products:", window.productsList);

  cartItemsContainer.innerHTML = "";

  let hasItems = false;
  const visibleItems = [];
  let totalItemsCount = 0;

  // Process regular products
  if (window.productsList && window.productsList.length > 0) {
    window.productsList.forEach((product) => {
      const qty = cart[product.id] || 0;
      if (qty > 0) {
        hasItems = true;
        totalItemsCount += qty;
        visibleItems.push({
          ...product,
          quantity: qty,
          isCustom: false
        });
        console.log(`✅ Regular product: ${product.name} x${qty}`);
      }
    });
  } else {
    console.error("❌ productsList is not available or empty!");
  }

  // Process custom products
  for (const productId in cart) {
    const qty = cart[productId] || 0;
    
    // Skip if already processed as regular product or quantity is 0
    if (qty <= 0) continue;
    
    // Check if it's a regular product (already processed above)
    const isRegularProduct = window.productsList && window.productsList.find(p => p.id === productId);
    if (isRegularProduct) continue;
    
    // Check if it's a custom product
    if (productId.includes('-custom-') || customProducts[productId]) {
      const customProduct = customProducts[productId];
      if (customProduct) {
        hasItems = true;
        totalItemsCount += qty;
        visibleItems.push({
          id: productId,
          name: customProduct.name || "Custom Item",
          price: customProduct.price || 0,
          image: getCustomProductImage(productId),
          quantity: qty,
          isCustom: true,
          description: customProduct.description,
          instructions: customProduct.instructions,
          emoji: customProduct.emoji || "🎨"
        });
        console.log(`✅ Custom product: ${customProduct.name} x${qty}`);
      }
    } else {
      // This is a regular product that might not be in productsList
      // Try to find it in productsList one more time
      const product = window.productsList?.find(p => p.id === productId);
      if (product && qty > 0) {
        hasItems = true;
        totalItemsCount += qty;
        visibleItems.push({
          ...product,
          quantity: qty,
          isCustom: false
        });
        console.log(`✅ Found product in cart: ${product.name} x${qty}`);
      }
    }
  }

  // Update item count text
  if (itemCountText) {
    itemCountText.textContent = `${totalItemsCount} item${totalItemsCount !== 1 ? "s" : ""}`;
  }

  // Render all items
  if (visibleItems.length === 0) {
    const emptyMsg = document.createElement("div");
    emptyMsg.className = "empty-cart";
    emptyMsg.innerHTML = `
      <div class="empty-cart-icon">🛒</div>
      <p>Your cart is empty</p>
      <a href="menu.html" class="continue-shopping">Continue Shopping</a>
    `;
    cartItemsContainer.appendChild(emptyMsg);
  } else {
    visibleItems.forEach((item) => {
      const card = document.createElement("article");
      card.classList.add("cart-item");
      card.setAttribute("data-id", item.id);

      // ---- IMAGE ----
      const imageDiv = document.createElement("div");
      imageDiv.classList.add("item-image");
      
      const img = document.createElement("img");
      img.src = item.image || 'default-product.png';
      img.alt = item.name;
      img.classList.add("item-img");
      img.onerror = function() {
        this.src = 'default-product.png'; // Fallback image
      };
      
      imageDiv.appendChild(img);

      // ---- TEXT INFO ----
      const infoDiv = document.createElement("div");
      infoDiv.classList.add("item-info");

      const nameEl = document.createElement("h2");
      nameEl.classList.add("item-name");
      nameEl.textContent = item.isCustom ? `${item.emoji} ${item.name}` : item.name;

      const priceEl = document.createElement("p");
      priceEl.classList.add("item-price");
      priceEl.textContent = `$${item.price.toFixed(2)} each`;

      infoDiv.appendChild(nameEl);
      infoDiv.appendChild(priceEl);

      // Add description for custom items
      if (item.isCustom && item.description) {
        const descEl = document.createElement("p");
        descEl.classList.add("item-description");
        descEl.style.fontSize = "12px";
        descEl.style.color = "var(--text-muted)";
        descEl.style.marginTop = "4px";
        descEl.textContent = item.description;
        infoDiv.appendChild(descEl);
      }

      // Add instructions for custom items
      if (item.isCustom && item.instructions) {
        const instructionsEl = document.createElement("p");
        instructionsEl.classList.add("item-instructions");
        instructionsEl.style.fontSize = "11px";
        instructionsEl.style.color = "var(--mocha)";
        instructionsEl.style.marginTop = "4px";
        instructionsEl.style.fontStyle = "italic";
        instructionsEl.textContent = `📝 ${item.instructions}`;
        infoDiv.appendChild(instructionsEl);
      }

      // ---- QUANTITY CONTROLS ----
      const qtyDiv = document.createElement("div");
      qtyDiv.classList.add("item-qty");

      const btnPlus = document.createElement("button");
      btnPlus.classList.add("qty-btn");
      btnPlus.textContent = "+";

      const qtyValue = document.createElement("span");
      qtyValue.classList.add("qty-value");
      qtyValue.textContent = item.quantity;

      const btnMinus = document.createElement("button");
      btnMinus.classList.add("qty-btn");
      btnMinus.textContent = "–";

      const totalPriceEl = document.createElement("div");
      totalPriceEl.style.marginTop = "8px";
      totalPriceEl.style.fontWeight = "600";
      totalPriceEl.style.color = "var(--accent)";
      totalPriceEl.textContent = `$${(item.price * item.quantity).toFixed(2)}`;

      qtyDiv.appendChild(btnMinus);
      qtyDiv.appendChild(qtyValue);
      qtyDiv.appendChild(btnPlus);
      qtyDiv.appendChild(totalPriceEl);

      // ---- ASSEMBLE CARD ----
      card.appendChild(imageDiv);
      card.appendChild(infoDiv);
      card.appendChild(qtyDiv);

      cartItemsContainer.appendChild(card);

      // ===== BUTTON BEHAVIOUR =====
      btnPlus.addEventListener("click", () => {
        changeCartQuantity(item.id, 1);
      });

      btnMinus.addEventListener("click", () => {
        changeCartQuantity(item.id, -1);
      });
    });
  }

  // Update totals
  updateTotals();
}

// ===== CHANGE CART QUANTITY =====
function changeCartQuantity(productId, change) {
  const cart = getSavedCart();
  const oldQty = cart[productId] || 0;
  let newQty = oldQty + change;

  if (newQty <= 0) {
    delete cart[productId];
    
    // Optional: Remove custom product details if quantity reaches 0
    if (productId.includes('-custom-')) {
      const customProducts = JSON.parse(localStorage.getItem('customProducts') || '{}');
      delete customProducts[productId];
      localStorage.setItem('customProducts', JSON.stringify(customProducts));
    }
  } else {
    cart[productId] = newQty;
  }

  saveCart(cart);
  renderCartItems();
  
  // Update cart icon on other pages if possible
  if (window.updateCartIcon) {
    window.updateCartIcon();
  }
}

// ===== UPDATE TOTALS =====
function updateTotals() {
  const cart = getSavedCart();
  const customProducts = JSON.parse(localStorage.getItem('customProducts') || '{}');
  
  let subtotal = 0;
  let itemCount = 0;

  // Calculate regular products
  if (window.productsList) {
    window.productsList.forEach((product) => {
      const qty = cart[product.id] || 0;
      subtotal += product.price * qty;
      itemCount += qty;
    });
  }

  // Calculate custom products
  for (const productId in cart) {
    // Skip if already processed as regular product
    if (window.productsList && window.productsList.find(p => p.id === productId)) continue;
    
    const qty = cart[productId] || 0;
    if (qty > 0) {
      const customProduct = customProducts[productId];
      if (customProduct) {
        subtotal += customProduct.price * qty;
        itemCount += qty;
      } else {
        // Try to find in productsList as fallback
        const product = window.productsList?.find(p => p.id === productId);
        if (product) {
          subtotal += product.price * qty;
          itemCount += qty;
        }
      }
    }
  }

  const total = subtotal;

  if (subtotalSpan) subtotalSpan.textContent = `$${subtotal.toFixed(2)}`;
  if (totalSpan) totalSpan.textContent = `$${total.toFixed(2)}`;
  
  // Update checkout button state
  const checkoutBtn = document.getElementById('checkoutBtn');
  if (checkoutBtn) {
    checkoutBtn.disabled = itemCount === 0;
  }
}

// ===== CUSTOM PRODUCT IMAGE HELPER =====
function getCustomProductImage(productId) {
  if (productId.includes('brownie-custom')) return 'brownie-custom.png';
  if (productId.includes('cake-custom')) return 'custom-cake.png';
  if (productId.includes('cheesecake-custom')) return 'custom-cake.png';
  if (productId.includes('cookie-custom')) return 'cookie-custom.png';
  return 'default-product.png';
}

// ===== NAVIGATION FUNCTIONS =====
function goBack() {
  if (document.referrer) {
    window.history.back();
  } else {
    window.location.href = "menu.html";
  }
}

function proceedToCheckout() {
  const cart = getSavedCart();
  const hasItems = Object.values(cart).some(qty => qty > 0);
  
  if (!hasItems) {
    alert('Your cart is empty. Please add some items before checkout.');
    return;
  }
  
  window.location.href = 'checkout.html';
}

// ===== INITIAL LOAD =====
document.addEventListener('DOMContentLoaded', function() {
  console.log("🛒 Cart page loaded");
  
  // Make sure productsList is available
  if (!window.productsList) {
    console.error("❌ productsList not found, loading products.js");
    // You might need to load products.js here if it's not already loaded
  }
  
  renderCartItems();
});

// Make functions available globally
window.renderCartItems = renderCartItems;
window.changeCartQuantity = changeCartQuantity;
window.updateTotals = updateTotals;