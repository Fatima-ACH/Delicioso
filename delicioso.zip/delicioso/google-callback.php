<?php
session_start();
require_once 'dbconnect.php';
require_once 'oauth-config.php';

if (isset($_GET['code'])) {
    $code = $_GET['code'];
    
    // Exchange code for access token
    $tokenUrl = 'https://oauth2.googleapis.com/token';
    $tokenData = [
        'code' => $code,
        'client_id' => GOOGLE_CLIENT_ID,
        'client_secret' => GOOGLE_CLIENT_SECRET,
        'redirect_uri' => GOOGLE_REDIRECT_URI,
        'grant_type' => 'authorization_code'
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $tokenUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($tokenData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $tokenResponse = curl_exec($ch);
    curl_close($ch);

    $tokenData = json_decode($tokenResponse, true);

    if (isset($tokenData['access_token'])) {
        // Get user info
        $userInfoUrl = 'https://www.googleapis.com/oauth2/v2/userinfo';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $userInfoUrl);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $tokenData['access_token']
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $userResponse = curl_exec($ch);
        curl_close($ch);

        $userData = json_decode($userResponse, true);

        // Check if user exists by Google ID OR by email
        $query = "SELECT * FROM users WHERE provider_id = ? AND provider = 'google' OR email = ?";
        $stmt = $db->prepare($query);
        $stmt->bind_param("ss", $userData['id'], $userData['email']);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // User exists, log them in (whether they registered with Google or email)
            $user = $result->fetch_assoc();
            $_SESSION['username'] = $user['username'];
            header('Location: index.php');
            exit;
        } else {
            // Create new user
            $email = $userData['email'];
            $username = explode('@', $email)[0] . '_google';
            $firstName = $userData['given_name'] ?? '';
            $lastName = $userData['family_name'] ?? '';
            $avatar = $userData['picture'] ?? '';

            // Make username unique
            $counter = 1;
            $originalUsername = $username;
            while (true) {
                $checkStmt = $db->prepare("SELECT id FROM users WHERE username = ?");
                $checkStmt->bind_param("s", $username);
                $checkStmt->execute();
                $checkStmt->store_result();
                
                if ($checkStmt->num_rows == 0) break;
                $username = $originalUsername . $counter;
                $counter++;
            }

            $insertQuery = "INSERT INTO users (first_name, last_name, username, email, password, provider, provider_id, avatar) 
                           VALUES (?, ?, ?, ?, '', 'google', ?, ?)";
            $insertStmt = $db->prepare($insertQuery);
            $insertStmt->bind_param("ssssss", $firstName, $lastName, $username, $email, $userData['id'], $avatar);

            if ($insertStmt->execute()) {
                $_SESSION['username'] = $username;
                header('Location: index.php');
                exit;
            } else {
                // If insert fails due to duplicate email, log the user in instead
                if ($db->errno == 1062) { // MySQL duplicate entry error code
                    $selectStmt = $db->prepare("SELECT * FROM users WHERE email = ?");
                    $selectStmt->bind_param("s", $email);
                    $selectStmt->execute();
                    $userResult = $selectStmt->get_result();
                    
                    if ($userResult->num_rows > 0) {
                        $user = $userResult->fetch_assoc();
                        $_SESSION['username'] = $user['username'];
                        header('Location: index.php');
                        exit;
                    }
                }
                header('Location: login.php?error=oauth_failed');
                exit;
            }
        }
    }
}

header('Location: login.php?error=oauth_failed');
exit;
?>