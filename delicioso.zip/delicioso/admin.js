// ADMIN.JS - COMPLETE WITH FORMDATA
console.log('🔄 Loading admin.js...');

const ORDER_STATUS = {
    NEW: 'new',
    PREPARING: 'preparing', 
    READY: 'ready',
    COMPLETED: 'completed'
};

const STATUS_CONFIG = {
    [ORDER_STATUS.NEW]: { 
        label: 'NEW', 
        class: 'status-new',
        nextStatus: ORDER_STATUS.PREPARING
    },
    [ORDER_STATUS.PREPARING]: { 
        label: 'PREPARING', 
        class: 'status-preparing',
        nextStatus: ORDER_STATUS.READY
    },
    [ORDER_STATUS.READY]: { 
        label: 'READY', 
        class: 'status-ready',
        nextStatus: ORDER_STATUS.COMPLETED
    },
    [ORDER_STATUS.COMPLETED]: { 
        label: 'COMPLETED', 
        class: 'status-completed',
        nextStatus: null
    }
};

// Fetch orders from MySQL database
async function getOrders() {
    try {
        const response = await fetch('get-orders.php');
        const result = await response.json();
        
        if (result.success) {
            console.log(`✅ Loaded ${result.orders.length} orders from database`);
            return result.orders;
        } else {
            console.error('❌ Failed to load orders:', result.error);
            return [];
        }
    } catch (error) {
        console.error('💥 Error loading orders:', error);
        return [];
    }
}

// Update order status - USING FORMDATA
async function updateOrderStatus(orderId, newStatus) {
    console.log(`🔄 Updating order ${orderId} to status: ${newStatus}`);
    
    try {
        // Use FormData (same as checkout)
        const formData = new FormData();
        formData.append('orderData', JSON.stringify({
            orderId: orderId,
            status: newStatus
        }));

        const response = await fetch('update-order-status.php', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        return result;
        
    } catch (error) {
        console.error('❌ Update request failed:', error);
        return {success: false, message: 'Request failed: ' + error.message};
    }
}

// Render orders function
function renderOrders(orders, filter = 'all') {
    const container = document.getElementById('ordersContainer');
    
    if (!orders || orders.length === 0) {
        container.innerHTML = '<div class="empty-orders">No orders found in database</div>';
        return;
    }
    
    const filteredOrders = filter === 'all' 
        ? orders 
        : orders.filter(order => order.status === filter);
    
    if (filteredOrders.length === 0) {
        container.innerHTML = '<div class="empty-orders">No orders match the selected filter</div>';
        return;
    }
    
    container.innerHTML = filteredOrders.map(order => `
        <div class="order-card" data-order-id="${order.order_id}">
            <div class="order-header">
                <div class="order-id">${order.order_id}</div>
                <div class="order-status ${STATUS_CONFIG[order.status]?.class || 'status-new'}">
                    ${STATUS_CONFIG[order.status]?.label || 'NEW'}
                </div>
            </div>
            
            <div class="customer-info">
                <p><strong>${order.customer_name}</strong></p>
                <p>📞 ${order.customer_phone}</p>
                <p>📧 ${order.customer_email}</p>
                <p>📍 ${order.delivery_address}</p>
                ${order.special_instructions ? `<p>💬 ${order.special_instructions}</p>` : ''}
                <p><small>🕒 ${new Date(order.created_at).toLocaleString()}</small></p>
            </div>
            
            <div class="order-items">
                ${order.items.map(item => `
                    <div class="order-item">
                        <span>${item.emoji || '🍽️'} ${item.name} × ${item.quantity}</span>
                        <span>$${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                `).join('')}
            </div>
            
            <div class="order-totals">
                <div>Subtotal: $${parseFloat(order.subtotal).toFixed(2)}</div>
                <div>Delivery: $${parseFloat(order.delivery_fee).toFixed(2)}</div>
                <div><strong>Total: $${parseFloat(order.total).toFixed(2)}</strong></div>
            </div>
            
            <div class="order-actions">
                ${order.status === ORDER_STATUS.NEW ? 
                    `<button class="action-btn btn-prepare" onclick="changeOrderStatus('${order.order_id}', '${ORDER_STATUS.PREPARING}')">
                        Start Preparing
                    </button>` : ''}
                ${order.status === ORDER_STATUS.PREPARING ? 
                    `<button class="action-btn btn-ready" onclick="changeOrderStatus('${order.order_id}', '${ORDER_STATUS.READY}')">
                        Mark Ready
                    </button>` : ''}
                ${order.status === ORDER_STATUS.READY ? 
                    `<button class="action-btn btn-complete" onclick="changeOrderStatus('${order.order_id}', '${ORDER_STATUS.COMPLETED}')">
                        Complete Order
                    </button>` : ''}
            </div>
        </div>
    `).join('');
}

async function changeOrderStatus(orderId, newStatus) {
    const result = await updateOrderStatus(orderId, newStatus);
    
    if (result.success) {
        loadOrders(); // Reload to show updated status
    } else {
        alert('Failed to update order status: ' + (result.message || 'Unknown error'));
    }
}

async function loadOrders() {
    const orders = await getOrders();
    const currentFilter = document.querySelector('.filter-btn.active')?.dataset.filter || 'all';
    renderOrders(orders, currentFilter);
}

// Initialize admin page
document.addEventListener('DOMContentLoaded', function() {
    console.log('👨‍💼 Admin page loaded');
    loadOrders();
    
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            loadOrders();
        });
    });
    
    setInterval(loadOrders, 10000);
});