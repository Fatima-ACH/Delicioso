<?php
// process-order.php - WITH YOUR EMAIL
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Include your existing database connection
require_once 'dbconnect.php';

// Get data
$input = $_POST['orderData'] ?? file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data || empty($data)) {
    echo json_encode(['success' => false, 'message' => 'No valid order data received']);
    exit;
}

try {
    // Generate order ID
    $orderId = 'DEL' . time() . rand(100, 999);
    
    // Prepare SQL query using mysqli
    $query = "INSERT INTO orders 
              (order_id, customer_name, customer_phone, customer_email, delivery_address, special_instructions, items, subtotal, delivery_fee, total) 
              VALUES 
              (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $db->prepare($query);
    
    // Convert items to JSON
    $itemsJson = json_encode($data['items']);
    
    // Bind parameters
    $stmt->bind_param("sssssssddd", 
        $orderId,
        $data['fullName'],
        $data['phone'],
        $data['email'],
        $data['deliveryAddress'],
        $data['specialInstructions'],
        $itemsJson,
        $data['subtotal'],
        $data['deliveryFee'],
        $data['total']
    );
    
    // Execute query
    if ($stmt->execute()) {
        // Send emails
        $emailResult = sendOrderEmails($data, $orderId);
        
        echo json_encode([
            'success' => true,
            'orderId' => $orderId,
            'message' => 'Order saved to database successfully!',
            'customerEmailSent' => $emailResult['customer'],
            'adminEmailSent' => $emailResult['admin'],
            'databaseSaved' => true
        ]);
    } else {
        throw new Exception('Failed to save order to database: ' . $stmt->error);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}

function sendOrderEmails($orderData, $orderId) {
    $customerEmail = $orderData['email'];
    $customerName = $orderData['fullName'];
    
    // Customer Email Content
    $customerSubject = "Order Confirmation - Delicioso #$orderId";
    $customerMessage = "
        Hi $customerName,
        
        Thank you for your order at Delicioso!
        
        ORDER DETAILS:
        Order ID: $orderId
        Total: $" . number_format($orderData['total'], 2) . "
        
        ITEMS:
    ";
    
    foreach ($orderData['items'] as $item) {
        $customerMessage .= "• {$item['name']} x {$item['quantity']} - $" . number_format($item['price'] * $item['quantity'], 2) . "\n";
    }
    
    $customerMessage .= "
        Delivery Address: {$orderData['deliveryAddress']}
        Special Instructions: {$orderData['specialInstructions']}
        
        We'll notify you when your order is ready for delivery!
        
        Best regards,
        Delicioso Team
    ";
    
    // Admin Email Content
    $adminSubject = "NEW ORDER #$orderId - Delicioso";
    $adminMessage = "
        NEW ORDER RECEIVED!
        
        Order ID: $orderId
        Customer: $customerName
        Phone: {$orderData['phone']}
        Email: $customerEmail
        
        DELIVERY:
        Address: {$orderData['deliveryAddress']}
        Instructions: {$orderData['specialInstructions']}
        
        ORDER ITEMS:
    ";
    
    foreach ($orderData['items'] as $item) {
        $adminMessage .= "• {$item['name']} x {$item['quantity']} - $" . number_format($item['price'] * $item['quantity'], 2) . "\n";
    }
    
    $adminMessage .= "
        ORDER SUMMARY:
        Subtotal: $" . number_format($orderData['subtotal'], 2) . "
        Delivery Fee: $" . number_format($orderData['deliveryFee'], 2) . "
        Total: $" . number_format($orderData['total'], 2) . "
        
        Login to admin panel to manage this order.
    ";
    
    // Send emails - USING YOUR EMAIL
    $customerSent = @mail($customerEmail, $customerSubject, $customerMessage);
    $adminSent = @mail('delicioso709@gmail.com', $adminSubject, $adminMessage);
    
    return [
        'customer' => $customerSent,
        'admin' => $adminSent
    ];
}
?>