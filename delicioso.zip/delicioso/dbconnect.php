<?php 
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = ''; 
$DB_NAME = 'delicioso_db';

$db = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($db->connect_error) {
    die("Database connection error: " . $db->connect_error);
}

$db->set_charset("utf8mb4");
?>
