<?php
session_start();
require_once 'dbconnect.php';
require_once 'oauth-config.php';

// Add this at the beginning of facebook-callback.php, right after session_start():
if (!isset($_GET['state']) || $_GET['state'] !== $_SESSION['oauth_state']) {
    // State validation failed - possible CSRF attack
    unset($_SESSION['oauth_state']);
    header('Location: login.php?error=invalid_state');
    exit;
}

// Clear the state after validation
unset($_SESSION['oauth_state']);
if (isset($_GET['code'])) {
    $code = $_GET['code'];
    
    // Exchange code for access token
    $tokenUrl = 'https://graph.facebook.com/v19.0/oauth/access_token?' . http_build_query([
        'client_id' => FACEBOOK_APP_ID,
        'client_secret' => FACEBOOK_APP_SECRET,
        'redirect_uri' => FACEBOOK_REDIRECT_URI,
        'code' => $code
    ]);

    $tokenResponse = file_get_contents($tokenUrl);
    $tokenData = json_decode($tokenResponse, true);

    if (isset($tokenData['access_token'])) {
        // Get user info
        $userInfoUrl = 'https://graph.facebook.com/v19.0/me?' . http_build_query([
            'fields' => 'id,name,email,first_name,last_name,picture.type(large)',
            'access_token' => $tokenData['access_token']
        ]);

        $userResponse = file_get_contents($userInfoUrl);
        $userData = json_decode($userResponse, true);

        if (isset($userData['id'])) {
            $email = $userData['email'] ?? $userData['id'] . '@facebook.com';
            
            // Check if user exists by Facebook ID OR by email
            $query = "SELECT * FROM users WHERE (provider_id = ? AND provider = 'facebook') OR email = ?";
            $stmt = $db->prepare($query);
            $stmt->bind_param("ss", $userData['id'], $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // User exists, log them in (whether they registered with Facebook or email)
                $user = $result->fetch_assoc();
                $_SESSION['username'] = $user['username'];
                header('Location: index.php');
                exit;
            } else {
                // Create new user
                $username = str_replace(' ', '_', strtolower($userData['name'])) . '_fb';
                $firstName = $userData['first_name'] ?? '';
                $lastName = $userData['last_name'] ?? '';
                $avatar = $userData['picture']['data']['url'] ?? '';

                // Make username unique
                $counter = 1;
                $originalUsername = $username;
                while (true) {
                    $checkStmt = $db->prepare("SELECT id FROM users WHERE username = ?");
                    $checkStmt->bind_param("s", $username);
                    $checkStmt->execute();
                    $checkStmt->store_result();
                    
                    if ($checkStmt->num_rows == 0) break;
                    $username = $originalUsername . $counter;
                    $counter++;
                }

                $insertQuery = "INSERT INTO users (first_name, last_name, username, email, password, provider, provider_id, avatar) 
                               VALUES (?, ?, ?, ?, '', 'facebook', ?, ?)";
                $insertStmt = $db->prepare($insertQuery);
                $insertStmt->bind_param("ssssss", $firstName, $lastName, $username, $email, $userData['id'], $avatar);

                if ($insertStmt->execute()) {
                    $_SESSION['username'] = $username;
                    header('Location: index.php');
                    exit;
                } else {
                    // If insert fails due to duplicate email, log the user in instead
                    if ($db->errno == 1062) { // MySQL duplicate entry error code
                        $selectStmt = $db->prepare("SELECT * FROM users WHERE email = ?");
                        $selectStmt->bind_param("s", $email);
                        $selectStmt->execute();
                        $userResult = $selectStmt->get_result();
                        
                        if ($userResult->num_rows > 0) {
                            $user = $userResult->fetch_assoc();
                            $_SESSION['username'] = $user['username'];
                            header('Location: index.php');
                            exit;
                        }
                    }
                    header('Location: login.php?error=oauth_failed');
                    exit;
                }
            }
        }
    }
}

header('Location: login.php?error=oauth_failed');
exit;

?>