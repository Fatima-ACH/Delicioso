 // ===== DELIVERY OPTIONS FUNCTIONALITY =====
        
        // Desktop delivery selection
        function selectDelivery(type) {
            // Remove selected class from all options
            document.querySelectorAll('.delivery-option').forEach(option => {
                option.classList.remove('selected');
            });
            
            // Add selected class to clicked option
            event.target.closest('.delivery-option').classList.add('selected');
            
            // Show/hide location selection
            const locationSelection = document.getElementById('locationSelection');
            if (type === 'delivery') {
                locationSelection.style.display = 'block';
            } else {
                locationSelection.style.display = 'none';
                // Reset location selection
                document.querySelectorAll('.location-option').forEach(option => {
                    option.classList.remove('selected');
                    option.querySelector('input').checked = false;
                });
            }
            
            updateOrderSummary();
        }
        
        // Mobile delivery selection
        function selectDeliveryMobile(type) {
            // Remove selected class from all options
            document.querySelectorAll('.mobile-delivery-option').forEach(option => {
                option.classList.remove('selected');
            });
            
            // Add selected class to clicked option
            event.target.closest('.mobile-delivery-option').classList.add('selected');
            
            // Show/hide location selection
            const locationSelection = document.getElementById('mobileLocationSelection');
            if (type === 'delivery') {
                locationSelection.style.display = 'block';
            } else {
                locationSelection.style.display = 'none';
                // Reset location selection
                document.querySelectorAll('.mobile-location-option').forEach(option => {
                    option.classList.remove('selected');
                    option.querySelector('input').checked = false;
                });
            }
            
            updateOrderSummaryMobile();
        }
        
        // Desktop location selection
        function selectLocation(location, fee) {
            // Remove selected class from all options
            document.querySelectorAll('.location-option').forEach(option => {
                option.classList.remove('selected');
                option.querySelector('input').checked = false;
            });
            
            // Add selected class to clicked option
            event.target.closest('.location-option').classList.add('selected');
            event.target.closest('.location-option').querySelector('input').checked = true;
            
            // Store delivery fee
            window.deliveryFee = fee;
            window.selectedLocation = location;
            
            updateOrderSummary();
        }
        
        // Mobile location selection
        function selectLocationMobile(location, fee) {
            // Remove selected class from all options
            document.querySelectorAll('.mobile-location-option').forEach(option => {
                option.classList.remove('selected');
                option.querySelector('input').checked = false;
            });
            
            // Add selected class to clicked option
            event.target.closest('.mobile-location-option').classList.add('selected');
            event.target.closest('.mobile-location-option').querySelector('input').checked = true;
            
            // Store delivery fee
            window.deliveryFeeMobile = fee;
            window.selectedLocationMobile = location;
            
            updateOrderSummaryMobile();
        }
        
        // ===== ORDER SUMMARY FUNCTIONALITY =====
        
        // Get cart items from localStorage
        function getCartItems() {
            const cart = JSON.parse(localStorage.getItem("dessertCart") || "{}");
            const products = getProductsList();
            const items = [];
            
            for (const productId in cart) {
                const quantity = cart[productId];
                if (quantity > 0) {
                    const product = products.find(p => p.id === productId);
                    if (product) {
                        items.push({
                            id: product.id,
                            name: product.name,
                            price: product.price,
                            quantity: quantity,
                            total: product.price * quantity
                        });
                    }
                }
            }
            
            return items;
        }
        
        // Update desktop order summary
        function updateOrderSummary() {
            const items = getCartItems();
            const itemsContainer = document.getElementById('preorderItems');
            const subtotalEl = document.getElementById('preorderSubtotal');
            const deliveryFeeEl = document.getElementById('deliveryFee');
            const deliveryFeeItem = document.getElementById('deliveryFeeItem');
            const totalEl = document.getElementById('preorderTotal');
            const confirmBtn = document.getElementById('confirmPreorder');
            
            let subtotal = 0;
            
            // Clear items container
            itemsContainer.innerHTML = '';
            
            if (items.length === 0) {
                itemsContainer.innerHTML = '<div class="empty-cart-message">Add items to cart first</div>';
                subtotalEl.textContent = '$0.00';
                totalEl.textContent = '$0.00';
                confirmBtn.disabled = true;
                confirmBtn.innerHTML = '<i class="fas fa-check-circle"></i> Confirm Preorder - $0.00';
                return;
            }
            
            // Add items to summary
            items.forEach(item => {
                const itemEl = document.createElement('div');
                itemEl.className = 'summary-item';
                itemEl.innerHTML = `
                    <span>${item.name} x${item.quantity}</span>
                    <span>$${item.total.toFixed(2)}</span>
                `;
                itemsContainer.appendChild(itemEl);
                subtotal += item.total;
            });
            
            // Calculate delivery fee
            let deliveryFee = 0;
            const isDelivery = document.querySelector('.delivery-option[data-type="delivery"]').classList.contains('selected');
            
            if (isDelivery && window.deliveryFee) {
                deliveryFee = window.deliveryFee;
                deliveryFeeItem.style.display = 'flex';
                deliveryFeeEl.textContent = `$${deliveryFee.toFixed(2)}`;
            } else {
                deliveryFeeItem.style.display = 'none';
            }
            
            // Update totals
            const total = subtotal + deliveryFee;
            subtotalEl.textContent = `$${subtotal.toFixed(2)}`;
            totalEl.textContent = `$${total.toFixed(2)}`;
            
            // Update confirm button
            confirmBtn.innerHTML = `<i class="fas fa-check-circle"></i> Confirm Preorder - $${total.toFixed(2)}`;
            
            // Check if date and time are selected
            const dateSelected = document.getElementById('preorderDate').value !== '';
            const timeSelected = document.getElementById('preorderTime').value !== '';
            
            // Enable button if all required fields are filled
            confirmBtn.disabled = !(dateSelected && timeSelected && items.length > 0);
        }
        
        // Update mobile order summary
        function updateOrderSummaryMobile() {
            const items = getCartItems();
            const itemsContainer = document.getElementById('mobilePreorderItems');
            const subtotalEl = document.getElementById('mobilePreorderSubtotal');
            const deliveryFeeEl = document.getElementById('mobileDeliveryFee');
            const deliveryFeeItem = document.getElementById('mobileDeliveryFeeItem');
            const totalEl = document.getElementById('mobilePreorderTotal');
            const confirmBtn = document.getElementById('mobileConfirmPreorder');
            
            let subtotal = 0;
            
            // Clear items container
            itemsContainer.innerHTML = '';
            
            if (items.length === 0) {
                itemsContainer.innerHTML = '<div class="mobile-empty-cart-message">Add items to cart first</div>';
                subtotalEl.textContent = '$0.00';
                totalEl.textContent = '$0.00';
                confirmBtn.disabled = true;
                confirmBtn.innerHTML = '<i class="fas fa-check-circle"></i> Confirm Preorder - $0.00';
                return;
            }
            
            // Add items to summary
            items.forEach(item => {
                const itemEl = document.createElement('div');
                itemEl.className = 'mobile-summary-item';
                itemEl.innerHTML = `
                    <span>${item.name} x${item.quantity}</span>
                    <span>$${item.total.toFixed(2)}</span>
                `;
                itemsContainer.appendChild(itemEl);
                subtotal += item.total;
            });
            
            // Calculate delivery fee
            let deliveryFee = 0;
            const isDelivery = document.querySelector('.mobile-delivery-option[data-type="delivery"]').classList.contains('selected');
            
            if (isDelivery && window.deliveryFeeMobile) {
                deliveryFee = window.deliveryFeeMobile;
                deliveryFeeItem.style.display = 'flex';
                deliveryFeeEl.textContent = `$${deliveryFee.toFixed(2)}`;
            } else {
                deliveryFeeItem.style.display = 'none';
            }
            
            // Update totals
            const total = subtotal + deliveryFee;
            subtotalEl.textContent = `$${subtotal.toFixed(2)}`;
            totalEl.textContent = `$${total.toFixed(2)}`;
            
            // Update confirm button
            confirmBtn.innerHTML = `<i class="fas fa-check-circle"></i> Confirm Preorder - $${total.toFixed(2)}`;
            
            // Check if date and time are selected
            const dateSelected = document.getElementById('mobilePreorderDate').value !== '';
            const timeSelected = document.getElementById('mobilePreorderTime').value !== '';
            
            // Enable button if all required fields are filled
            confirmBtn.disabled = !(dateSelected && timeSelected && items.length > 0);
        }
        
        // ===== CONFIRM BUTTON UPDATES =====
        
        function updateConfirmButton() {
            updateOrderSummary();
        }
        
        function updateConfirmButtonMobile() {
            updateOrderSummaryMobile();
        }
        
        // ===== PREORDER CONFIRMATION =====
        
        function confirmPreorder() {
            alert('Preorder confirmed! You will receive a confirmation message.');
            // In a real app, you would send this data to a server
        }
        
        function confirmPreorderMobile() {
            alert('Preorder confirmed! You will receive a confirmation message.');
            // In a real app, you would send this data to a server
        }
        
        // ===== PRODUCTS LIST =====
        
        function getProductsList() {
            return [
                // Cheesecakes
                {
                    id: "cheesecake-lotus",
                    category: "cheesecake",
                    name: "Lotus Cheesecake",
                    price: 3.00,
                    emoji: "🍰"
                },
                {
                    id: "cheesecake-passionfruit",
                    category: "cheesecake",
                    name: "Passion Fruit Cheesecake",
                    price: 3.00,
                    emoji: "🍰"
                },
                {
                    id: "cheesecake-oreo",
                    category: "cheesecake",
                    name: "Oreo Cheesecake",
                    price: 3.00,
                    emoji: "🍰"
                },
                {
                    id: "cheesecake-custom",
                    category: "cheesecake",
                    name: "Custom Cheesecake",
                    price: 4.00,
                    emoji: "🎨"
                },

                // Cakes
                {
                    id: "cake-bounty",
                    category: "cake",
                    name: "Bounty Cake",
                    price: 3.00,
                    emoji: "🍰"
                },
                {
                    id: "cake-tres-leches-large",
                    category: "cake",
                    name: "Tres Leches Cake (Large)",
                    price: 3.00,
                    emoji: "🍰"
                },
                {
                    id: "cake-tres-leches-small",
                    category: "cake",
                    name: "Tres Leches Cake (Small)",
                    price: 1.50,
                    emoji: "🍰"
                },
                {
                    id: "cake-cocoberry",
                    category: "cake",
                    name: "Cocoberry Cake",
                    price: 3.00,
                    emoji: "🍰"
                },
                {
                    id: "cake-dubai-chocolate",
                    category: "cake",
                    name: "Dubai Chocolate Cake",
                    price: 3.00,
                    emoji: "🍰"
                },
                {
                    id: "cake-redvelvet",
                    category: "cake",
                    name: "Red Velvet Cake",
                    price: 3.00,
                    emoji: "🍰"
                },
                {
                    id: "cake-custom",
                    category: "cake",
                    name: "Custom Cake",
                    price: 16.00,
                    emoji: "🎨"
                },

                // Brownies
                {
                    id: "brownie-oreo",
                    category: "brownie",
                    name: "Oreo Brownie",
                    price: 3.00,
                    emoji: "🍫"
                },
                {
                    id: "brownie-kinder",
                    category: "brownie",
                    name: "Kinder Brownie",
                    price: 3.00,
                    emoji: "🍫"
                },
                {
                    id: "brownie-lotus",
                    category: "brownie",
                    name: "Lotus Brownie",
                    price: 3.00,
                    emoji: "🍫"
                },
                {
                    id: "brownie-pistachio",
                    category: "brownie",
                    name: "Pistachio Brownie",
                    price: 3.00,
                    emoji: "🍫"
                },
                {
                    id: "brownie-custom",
                    category: "brownie",
                    name: "Custom Brownie",
                    price: 3.00,
                    emoji: "🎨"
                },

                // Cookies
                {
                    id: "cookie-normal",
                    category: "cookie",
                    name: "Classic Cookie (6pc)",
                    price: 4.50,
                    emoji: "🍪"
                },
                {
                    id: "cookie-redvelvet",
                    category: "cookie",
                    name: "Red Velvet Cookie (3pc)",
                    price: 2.25,
                    emoji: "🍪"
                },
                {
                    id: "cookie-chocolate-kinder",
                    category: "cookie",
                    name: "Chocolate Kinder Cookie (3pc)",
                    price: 2.25,
                    emoji: "🍪"
                },
                {
                    id: "cookie-chocolate-nutella",
                    category: "cookie",
                    name: "Chocolate Nutella Cookie (3pc)",
                    price: 2.25,
                    emoji: "🍪"
                },
                {
                    id: "cookie-custom",
                    category: "cookie",
                    name: "Custom Cookie",
                    price: 2.25,
                    emoji: "🎨"
                }
            ];
        }
        
        // Initialize when page loads
        document.addEventListener('DOMContentLoaded', function() {
            // Set minimum date to today
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('preorderDate').min = today;
            document.getElementById('mobilePreorderDate').min = today;
            
            // Load cart items
            updateOrderSummary();
            updateOrderSummaryMobile();
        });