<?php
session_start();
include("dbconnect.php");
// After successful login validation
$_SESSION['user_logged_in'] = true;

// Add a class to the body to indicate logged-in status
echo '<body class="logged-in">';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $query = "SELECT * FROM users WHERE email = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row["password"])) {
            $_SESSION["username"] = $row["username"];
        header("Location: index.php");
            exit;
        } else {
            $message = "❌ Incorrect password.";
        }
    } else {
        $message = "❌ Email not found.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="icon" href="delicioso.png">
    <link rel="stylesheet" href="s.css">
    <style>
        /* Mobile fix only - keeps your exact design */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
                height: auto;
                min-height: 100vh;
                align-items: center;
            }
            .form-wrapper {
                width: 100%;
                max-width: 340px;
                margin: 0 auto;
            }
            body, html {
                overflow: auto;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="background-image"></div>
    <div class="form-wrapper">
        <h1 class="logo">Delicioso</h1>

        <?php if ($message != "") echo "<p style='color:red;text-align:center;'>$message</p>"; ?>

        <form action="login.php" method="POST" class="form active">
            <h2>Log In</h2>

            <label>Email:</label>
            <input name="email" type="email" required>

            <label>Password:</label>
            <input name="password" type="password" required>

            <button class="btn" type="submit">Log In</button>

            <div class="divider">
                <span>or continue with</span>
            </div>

            <div class="social-login">
                <a href="google-auth.php" class="social-btn google" title="Sign in with Google">
                    <span class="social-icon">G</span>
                </a>
                <a href="facebook-auth.php" class="social-btn facebook" title="Sign in with Facebook">
                    <span class="social-icon">f</span>
                </a>
            </div>

            <p>Don't have an account?
                <a href="register.php">Sign Up</a>
            </p>
        </form>
    </div>
</div>

</body>
</html>