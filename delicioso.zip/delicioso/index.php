<?php
session_start();
$username   = isset($_SESSION["username"]) ? $_SESSION["username"] : null;
$registered = isset($_GET['registered']) ? true : false;
$isLoggedIn = isset($_SESSION["username"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delicioso By Hamidi - Homemade Desserts</title>
    <link rel="icon" href="delicioso.png">

    <!-- External libraries -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">

    <!-- Your CSS file -->
    <link rel="stylesheet" href="stylesindex.css">
</head>
<body data-logged-in="<?php echo $isLoggedIn ? 'true' : 'false'; ?>">

    <!-- Header with Menu Button -->
    <header class="header">
        <div class="header-left">
            <button class="menu-toggle" id="menuToggle">
                <i class="fas fa-bars"></i>
            </button>
            <a href="index.php" class="logo">
                <img src="delicioso.png" alt="Delicioso Logo" class="logo-image">
                <span class="brand-name">Delicioso</span>
            </a>
        </div>
        <div class="header-right">
            <!-- Show these when user is logged out -->
            <div id="loggedOutButtons" class="auth-buttons">
                <a href="login.php" class="auth-btn">
                    <i class="fas fa-sign-in-alt"></i> Log In
                </a>
                <a href="register.php" class="auth-btn">
                    <i class="fas fa-user-plus"></i> Register
                </a>
            </div>

            <!-- Show animated logout button when user is logged in -->
            <div id="loggedInButtons" class="logout-button-container" style="display: none;">
                <button class="logoutButton">
                    <span class="button-text">Logout</span>
                    <svg class="figure" viewBox="0 0 512 512">
                        <g class="body">
                            <circle cx="256" cy="256" r="50" fill="#986C55"/>
                        </g>
                        <g class="arm1">
                            <line x1="256" y1="256" x2="220" y2="220" stroke="#986C55" stroke-width="10"/>
                        </g>
                        <g class="wrist1">
                            <circle cx="220" cy="220" r="8" fill="#986C55"/>
                        </g>
                        <g class="arm2">
                            <line x1="256" y1="256" x2="292" y2="220" stroke="#986C55" stroke-width="10"/>
                        </g>
                        <g class="wrist2">
                            <circle cx="292" cy="220" r="8" fill="#986C55"/>
                        </g>
                        <g class="leg1">
                            <line x1="256" y1="306" x2="230" y2="350" stroke="#986C55" stroke-width="10"/>
                        </g>
                        <g class="calf1">
                            <line x1="230" y1="350" x2="220" y2="380" stroke="#986C55" stroke-width="8"/>
                        </g>
                        <g class="leg2">
                            <line x1="256" y1="306" x2="282" y2="350" stroke="#986C55" stroke-width="10"/>
                        </g>
                        <g class="calf2">
                            <line x1="282" y1="350" x2="292" y2="380" stroke="#986C55" stroke-width="8"/>
                        </g>
                    </svg>
                    <svg class="doorway" viewBox="0 0 512 512">
                        <rect x="200" y="150" width="112" height="250" fill="#EBDDA8"/>
                    </svg>
                    <svg class="door" viewBox="0 0 512 512">
                        <path d="M200,150 L312,150 L312,400 L200,400 Z" fill="#986C55" stroke="#986C55" stroke-width="4"/>
                    </svg>
                    <svg class="bang" viewBox="0 0 512 512">
                        <circle cx="256" cy="256" r="100" fill="#ffffff" opacity="0.4"/>
                    </svg>
                </button>
            </div>
        </div>
    </header>

    <!-- Sliding Menu - UPDATED with About Us -->
    <div class="sliding-menu" id="slidingMenu">
        <div class="menu-header">
            <h2 class="brand-name">Delicioso</h2>
            <button class="close-menu" id="closeMenu">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <ul class="menu-categories">
            <li><a href="best_sellers.html"><i class="fas fa-star"></i> Best Sellers</a></li>
            <li><a href="Cheesecake.html"><i class="fas fa-cheese"></i> Cheesecake</a></li>
            <li><a href="Cakes.html"><i class="fas fa-birthday-cake"></i> Cakes</a></li>
            <li><a href="Brownies.html"><i class="fas fa-cube"></i> Brownies</a></li>
            <li><a href="Cookies.html"><i class="fas fa-cookie"></i> Cookies</a></li>
            <li><a href="about.html"><i class="fas fa-info-circle"></i> About Us</a></li> <!-- ADDED -->
            <li><a href="preorder.html"><i class="fas fa-calendar-alt"></i> Preorder</a></li>
            <li><a href="location.html"><i class="fas fa-map-marker-alt"></i> Location</a></li>
            <li><a href="cart.html"><i class="fas fa-shopping-cart"></i> Cart</a></li>
        </ul>
    </div>

    <!-- Overlay when menu is open -->
    <div class="menu-overlay" id="menuOverlay"></div>

    <!-- Hero Section with big image -->
<section class="hero-section hero-clean">
    <div class="hero-clean-inner">

        <h1 class="hero-title">Delicioso By Hamidi</h1>

        <p class="hero-subtitle">
            Sweet moments, lasting memories — homemade desserts crafted with love. We are located in Al Manara, West Bekaa.
        </p>

        <div class="hero-buttons">
            <a href="menu.html" class="hero-btn primary-btn">
                <i class="fas fa-utensils"></i> View Our Menu
            </a>
            <a href="preorder.html" class="hero-btn secondary-btn">
                <i class="fas fa-calendar-alt"></i> Preorder Now
            </a>
        </div>

    </div>
</section>


    <!-- BEST SELLERS SLIDER -->
<section class="best-sellers-section">
  <div class="section-strip">
    <div class="section-strip-inner">
      <span>Take a Look At Our Best Sellers</span>
      <span>Take a Look At Our Best Sellers</span>
      <span>Take a Look At Our Best Sellers</span>
      <span>Take a Look At Our Best Sellers</span>
      <span>Take a Look At Our Best Sellers</span>
      <span>Take a Look At Our Best Sellers</span>
      <span>Take a Look At Our Best Sellers</span>
      <span>Take a Look At Our Best Sellers</span>
    </div>
  </div>

  <div class="slider-wrapper">
    <div class="scroll-container" id="bestSlider">

      <div class="product-card">
        <a href="brownies.html" class="product-link">
          <div class="product-img">
            <img src="slide_brownie.jpg" alt="Oreo Brownie">
          </div>
          <h3>Oreo Brownie</h3>
        </a>
      </div>

      <div class="product-card">
        <a href="cakes.html" class="product-link">
          <div class="product-img">
            <img src="slide_cake.jpg" alt="Red Velvet Cake">
          </div>
          <h3>Red Velvet Cake</h3>
        </a>
      </div>

      <div class="product-card">
        <a href="Cheesecake.html" class="product-link">
          <div class="product-img">
            <img src="slide_cheesecake.jpg" alt="Lotus Cheesecake">
          </div>
          <h3>Lotus Cheesecake</h3>
        </a>
      </div>

      <div class="product-card">
        <a href="cookies.html" class="product-link">
          <div class="product-img">
            <img src="slide_cookie.jpg" alt="Cookie Box">
          </div>
          <h3>Cookie Box</h3>
        </a>
      </div>

    </div>

    <div class="slider-dots" id="bestDots">
      <span class="dot active"></span>
      <span class="dot"></span>
      <span class="dot"></span>
      <span class="dot"></span>
    </div>
  </div>
</section>


<!-- CATEGORIES SLIDER -->
<section class="gift-section">
  <div class="section-strip">
    <div class="section-strip-inner">
        <span>So Many Categories To Choose From</span>
        <span>So Many Categories To Choose From</span>
        <span>So Many Categories To Choose From</span>
        <span>So Many Categories To Choose From</span>
        <span>So Many Categories To Choose From</span>
        <span>So Many Categories To Choose From</span>
        <span>So Many Categories To Choose From</span>
    </div>
</div>


  <div class="slider-wrapper">
    <div class="scroll-container" id="giftSlider">
    <a href="cheesecake.html" class="product-link">
      <div class="product-card">
        <div class="product-img">
          <img src="slide2_cheesecake.jpg" alt="Cheesecakes">
        </div>
        <h3>Cheesecake</h3>
    </a>
      </div>

      <a href="cakes.html" class="product-link">
      <div class="product-card">
        <div class="product-img">
          <img src="dubaichocolatecake.jpeg" alt="Cakes">
        </div>
        <h3>Cakes</h3>
</a>
      </div>

      <a href="brownies.html" class="product-link">
      <div class="product-card">
        <div class="product-img">
          <img src="slide2_brownie.jpg" alt="Brownies">
        </div>
        <h3>Brownies</h3>
</a>
      </div>

      <a href="cookies.html" class="product-link">
      <div class="product-card">
        <div class="product-img">
          <img src="slide_cookie.jpg" alt="Cookies">
        </div>
        <h3>Cookies Box</h3>
</a> 
      </div>

    </div>

    <div class="slider-dots" id="giftDots">
      <span class="dot active"></span>
      <span class="dot"></span>
      <span class="dot"></span>
      <span class="dot"></span>
    </div>
  </div>
</section>


    <!-- Dark contrast section (your "random filling" section) -->
    <section class="categories-section">
        <h2 class="highlights-title steps-title">
            Why choose Delicioso? We are sure you won't regret.
        </h2>

        <div class="steps-list">
            <div class="step-card">
                <div class="step-icon">
                    <img src="spoon-and-fork.png" alt="Homemade">
                </div>
                <div class="step-content">
                    <h3>Homemade</h3>
                    <p>
                        Freshly made with love, using quality ingredients every day.
                        Every dessert is made from scratch in our home kitchen using
                        traditional recipes and the finest ingredients.
                    </p>
                </div>
            </div>

            <div class="step-card">
                <div class="step-icon">
                    <img src="box.png" alt="Delivery">
                </div>
                <div class="step-content">
                    <h3>Delivery</h3>
                    <p>
                        Order ahead and grab your treats at your convenience.
                        We deliver throughout West Bekaa with same-day delivery available
                        for orders before 2:00 PM.
                    </p>
                </div>
            </div>

            <div class="step-card">
                <div class="step-icon">
                    <img src="pencil-and-ruler.png" alt="Custom">
                </div>
                <div class="step-content">
                    <h3>Custom Cakes</h3>
                    <p>
                        Personalized desserts for any events. Reach us through WhatsApp and
                        we'll make sure to recreate any cake you want.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="testimonials-section">
        <h2 class="section-title">What Our Customers Say</h2>
        <div class="testimonials-grid">
            <div class="testimonial-card">
                <div class="testimonial-stars">★★★★★</div>
                <p class="testimonial-text">
                    "The Lotus Cheesecake is absolutely divine! The perfect balance of creamy and crunchy. I order it every week!"
                </p>
                <div class="testimonial-author">- Regular Customer</div>
            </div>
            <div class="testimonial-card">
                <div class="testimonial-stars">★★★★★</div>
                <p class="testimonial-text">
                    "Best Tres Leches I've had outside of Latin America! Moist, sweet, and absolutely perfect texture."
                </p>
                <div class="testimonial-author">- Dessert Lover</div>
            </div>
            <div class="testimonial-card">
                <div class="testimonial-stars">★★★★★</div>
                <p class="testimonial-text">
                    "The custom brownie with Kinder and pistachio toppings is my new addiction. So rich and delicious!"
                </p>
                <div class="testimonial-author">- Chocolate Enthusiast</div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>Delicioso By Hamidi</h3>
                <p>
                    Homemade desserts crafted with love in Al Manara, West Bekaa. Sweet moments, lasting memories.
                </p>
                <div class="social-links">
                    <a href="https://www.instagram.com/delicioso.by.hamidi?igsh=dXU0MW1mOGZ5M2Zy" class="social-icon" aria-label="Instagram">
                        <i class="fab fa-instagram"></i>
                    </a>
                </div>
            </div>
            <div class="footer-section">
                <h3>Learn</h3>
                <ul class="footer-links">
                    <li><a href="about.html">About Delicioso</a></li>
                    <li><a href="location.html">Contact Us</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Orders</h3>
                <ul class="footer-links">
                    <li><a href="best_sellers.html">Best Sellers</a></li>
                    <li><a href="menu.html">Full Menu</a></li>
                    <li><a href="preorder.html">Preorder</a></li>
                    <li><a href="location.html">Location &amp; Delivery</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date("Y"); ?> Delicioso By Hamidi. All rights reserved.</p>
            <p>Sweet Moments, Lasting Memories</p>
        </div>
    </footer>

    <!-- JS -->
    <script src="main.js"></script>
</body>
</html>